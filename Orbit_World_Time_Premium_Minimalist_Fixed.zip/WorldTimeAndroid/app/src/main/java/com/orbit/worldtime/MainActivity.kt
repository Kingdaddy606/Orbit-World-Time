package com.orbit.worldtime

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("orbit_world_time", Context.MODE_PRIVATE) }
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var pinnedLabel: TextView
    private var query = ""
    private val ink = Color.rgb(29, 37, 48)
    private val muted = Color.rgb(112, 123, 135)
    private val accent = Color.rgb(27, 125, 111)
    private val paper = Color.rgb(247, 248, 246)
    private val card = Color.WHITE
    private val line = Color.rgb(228, 232, 229)
    private val handler = Handler(Looper.getMainLooper())
    private val zones: List<String> by lazy { TimeZone.getAvailableIDs().filter { it.contains('/') && !it.startsWith("Etc/") }.distinct().sorted() }
    private val defaults = listOf("Africa/Lagos", "Europe/London", "America/New_York", "Asia/Tokyo")

    private fun selected(): MutableList<String> {
        val ordered = prefs.getString("selected_zones_ordered", null)
        if (ordered != null) return ordered.split("|").filter { it.isNotBlank() }.distinct().toMutableList()
        val old = prefs.getStringSet("selected_zones", null)
        val migrated = if (old == null) defaults else defaults.filter { old.contains(it) } + old.filter { it !in defaults }.sorted()
        saveSelected(migrated)
        return migrated.toMutableList()
    }
    private fun saveSelected(items: List<String>) {
        prefs.edit().putString("selected_zones_ordered", items.distinct().joinToString("|"))
            .putStringSet("selected_zones", items.toSet()).apply()
    }
    private val tick = object : Runnable {
        override fun run() {
            if (::list.isInitialized) for (i in 0 until list.childCount) {
                val row = list.getChildAt(i) as? LinearLayout ?: continue
                val id = row.tag as? String ?: continue
                val right = row.getChildAt(1) as? LinearLayout ?: continue
                val time = right.getChildAt(0) as? TextView ?: continue
                time.text = timeFor(id)
            }
            handler.postDelayed(this, 1000)
        }
    }
    private val localTick = object : Runnable {
        override fun run() {
            if (::localTime.isInitialized) {
                val now = Date()
                localTime.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
                localDate.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)
            }
            handler.postDelayed(this, 1000)
        }
    }
    private lateinit var localTime: TextView
    private lateinit var localDate: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = paper; window.navigationBarColor = paper
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        selected(); buildUi(); renderList(); handler.post(tick); handler.post(localTick)
    }
    override fun onDestroy() { handler.removeCallbacks(tick); handler.removeCallbacks(localTick); super.onDestroy() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD); includeFontPadding = true
    }
    private fun params(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(paper) }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setPadding(dp(20), dp(20), dp(20), dp(24)) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(text("ORBIT   /   WORLD TIME", 11f, accent, true).apply { letterSpacing = .13f }, params(bottom = 16))
        content.addView(text("Time, at a glance.", 30f, ink, true), params(bottom = 6))
        content.addView(text("Your world, across every time zone.", 14f, muted), params(bottom = 22))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); background = rounded(ink, 22) }
        hero.addView(text("YOUR LOCAL TIME", 10f, Color.rgb(164, 211, 198), true).apply { letterSpacing = .12f })
        hero.addView(text(TimeZone.getDefault().id.substringAfterLast('/').replace('_', ' '), 18f, Color.WHITE, true), params(top = 8, bottom = 4))
        localTime = text("--:--:--", 38f, Color.WHITE, false).apply { typeface = Typeface.create("sans-serif", Typeface.NORMAL); letterSpacing = -.03f }
        hero.addView(localTime); localDate = text("", 12f, Color.rgb(207, 215, 220)); hero.addView(localDate, params(top = 3))
        content.addView(hero, params(bottom = 26))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heading.addView(text("Pinned clocks", 21f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        pinnedLabel = text("4 PINNED", 10f, accent, true).apply { letterSpacing = .04f }; heading.addView(pinnedLabel)
        content.addView(heading, params(bottom = 6))
        content.addView(text("Tap a city to pin or unpin it. Your first four pins appear on the home-screen widget.", 13f, muted), params(bottom = 14))
        search = EditText(this).apply { hint = "Search cities or time zones"; setHintTextColor(muted); setTextColor(ink); textSize = 15f; setSingleLine(true); imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH; setPadding(dp(16), 0, dp(16), 0); background = rounded(card, 15, line) }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(14) })
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString()?.trim()?.lowercase(Locale.ROOT) ?: ""; renderList() }
            override fun afterTextChanged(s: Editable?) {}
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        content.addView(text("TIME ZONES PROVIDED BY YOUR DEVICE  ·  WORKS OFFLINE", 9f, muted, true).apply { gravity = Gravity.CENTER; letterSpacing = .04f }, params(top = 22, bottom = 12))
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
    }
    private fun cityName(id: String) = id.substringAfterLast('/').replace('_', ' ')
    private fun regionName(id: String) = when (id.substringBefore('/')) {
        "Africa" -> "AFRICA"; "America" -> "AMERICAS"; "Antarctica" -> "ANTARCTICA"; "Asia" -> "ASIA"; "Atlantic" -> "ATLANTIC"; "Australia" -> "OCEANIA"; "Europe" -> "EUROPE"; "Indian" -> "INDIAN OCEAN"; "Pacific" -> "PACIFIC"; else -> id.substringBefore('/').uppercase(Locale.ROOT)
    }
    private fun timeFor(id: String): String { val f = SimpleDateFormat("HH:mm", Locale.getDefault()); f.timeZone = TimeZone.getTimeZone(id); return f.format(Date()) }
    private fun renderList() {
        if (!::list.isInitialized) return
        list.removeAllViews(); val pins = selected(); pinnedLabel.text = "${pins.size} PINNED"
        val filtered = zones.filter { query.isBlank() || it.lowercase(Locale.ROOT).contains(query) || cityName(it).lowercase(Locale.ROOT).contains(query) || regionName(it).lowercase(Locale.ROOT).contains(query) }
        if (filtered.isEmpty()) { list.addView(text("No matching time zones. Try London, Lagos or Tokyo.", 14f, muted).apply { setPadding(dp(8), dp(20), dp(8), dp(20)) }); return }
        var lastRegion = ""
        filtered.forEach { id ->
            val region = regionName(id)
            if (region != lastRegion) { list.addView(text(region, 10f, accent, true).apply { letterSpacing = .12f; setPadding(dp(4), dp(14), 0, dp(8)) }); lastRegion = region }
            val isPinned = pins.contains(id)
            val row = LinearLayout(this).apply { tag = id; orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)); background = rounded(if (isPinned) Color.rgb(235, 245, 241) else card, 16, if (isPinned) Color.rgb(190, 222, 211) else line); isClickable = true; isFocusable = true }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; left.addView(text(cityName(id), 15f, ink, true)); left.addView(text(id.replace('_', ' '), 10f, muted).apply { setPadding(0, dp(3), 0, 0) }); row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
            val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }; right.addView(text(timeFor(id), 19f, ink, true).apply { typeface = Typeface.create("monospace", Typeface.NORMAL) }); right.addView(text(if (isPinned) "✓ PINNED" else "+ PIN", 10f, if (isPinned) accent else muted, true).apply { setPadding(0, dp(3), 0, 0) }); row.addView(right)
            row.setOnClickListener { val current = selected(); if (current.contains(id)) current.remove(id) else current.add(id); saveSelected(current); updateWidgets(); renderList(); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0) }
            list.addView(row, params(bottom = 8))
        }
    }
    private fun updateWidgets() { val manager = AppWidgetManager.getInstance(this); manager.getAppWidgetIds(ComponentName(this, WorldClockWidget::class.java)).forEach { WorldClockWidget.update(this, manager, it) } }
}
